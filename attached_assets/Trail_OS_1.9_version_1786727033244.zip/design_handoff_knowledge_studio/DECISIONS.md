# Decisions — Knowledge Studio

The reasoning behind the design. Most of these look like details and are load-bearing.

---

## The single-field Procedure is the root problem

`Procedure` carries eleven steps and three inline screenshots in one rich-text field. Every other failure is downstream: a reader cannot find step 6, a screenshot belongs to nothing, no step can carry a verify line or a link, and Penny retrieves the whole wall or nothing.

Making each step a record fixes all of it at once. **This is the change; the rest is consequence.**

## The same structure serves the human and the AI

A step with an instruction, a screenshot, a direct link and a verify line is what someone working alone needs. It is also exactly what Penny needs to cite one step instead of an article. These are not competing goals that had to be balanced — they turned out to be the same goal, which is why the design does not have a "Penny mode".

## One capture session, three outputs

The Procedure Builder session already captures these frames for the kit Build pages and the Build With Me video. A knowledge article is the third consumer of the same session. Taking the screenshot *while writing the step* is the only way it stays current — a screenshot taken later is a screenshot of a different version.

## Every capture is stamped with the version it was taken against

This is the staleness detector that scales. When a tool version moves, every frame captured below it lights up at once, and the stale ones cluster by session because they were taken together. Re-capturing by session is a morning; by article it is a fortnight.

## Still or clip, chosen per step

A still for where something is — cheap to retake, and what most steps need. A short clip only where a click has a consequence you cannot photograph. Clips cost more to re-record, so a clip on a step that only needed a still is a step that will go stale and stay stale.

## The reader is the fastest staleness detector

They are looking at the real screen while reading your description of it. Nobody is better placed. So the report is **one tap, no form**, and it lands on **the step, not the article** — three reports on one step is a fact; three on one article is a shrug.

## Required blocks; suggested does not

Required means one of three things: it will be wrong soon (a person's name, a version in prose, a menu path with no link), it stops the reader (go and find, go and search, ask someone), or it breaks a rule already written down (no verify line, a price in the body, British spelling). Everything else is a suggestion.

**Keeping that line honest is the whole mechanism.** A required list of eleven items is a list people learn to override, and an approver reading nine articles a month will approve whatever is in front of them.

## Penny's review runs before the human gate, and is third in the build order

She can only check what is structured, so the review is worth little until steps and categories exist. Building it first would produce a reviewer that mostly says "this is one big field".

## Two kinds of summary, and only one of them is generated

`Overview` is the author saying why the article exists — keep it, human-written. A generated summary placed above it would eventually disagree with it, teach readers to skip the top of every article, and remove the reason anyone writes Overview.

What Penny needs is not a summary but a **retrieval abstract**: the questions this answers in the words people ask them, and — the load-bearing field — **what it does not cover**. That exclusion list is what stops her answering a nearby question from this article and sounding confident about it.

## The abstract regenerates at publish, never at creation, and is never hand-edited

An abstract written when the record is created describes a draft nobody kept. **A stale retrieval index is worse than stale prose, because it fails silently and confidently** — the reader can see that a screenshot looks wrong; nobody can see that the thing answering their question is indexed against version 1.

Not hand-editable for the same reason: if the abstract reads wrong, the article is wrong. Fix that.

## Relationships are typed and directional

An untyped list of related articles gives every Penny identity the same four links and no way to choose. The type is what makes the graph walkable: Coach follows Prerequisite backwards, Quest Guide follows Next step forwards one hop, Client Liaison follows Other side only.

**Six types, deliberately.** A longer list becomes a dropdown nobody reads carefully, and a wrong type is worse than no link.

## Every link writes its inverse

Marking this the next step of another article makes that one this article's prerequisite. A one-way relationship is how a knowledge graph quietly becomes wrong in one direction — and the wrong direction is usually the one nobody tests.

## A link to an unpublished article holds rather than dangles

It sits Pending and resolves when the target publishes. Penny never traverses into a draft. The alternative is someone remembering to come back, and nobody does.

## Other side is the type that solves the audience problem

Same task, opposite audience — the admin who invites and the learner who accepts. It lets Penny start on an internal article, cross one edge, and answer a learner having quoted nothing from where she started. Without it she has to either refuse or leak.

## Three audiences, three articles — never one article with conditional blocks

A step someone has no permission for is not a caveat, it is a dead end. Conditional prose is how an article becomes unreadable for everyone.

## Categorizing, linking and publishing are one act by one person

All three need the Knowledge Manager license, and a relationship writes an inverse onto *another published article* — a record the author may not own. Putting them in the same gated act means an article cannot reach in-app help uncategorized or unlinked.

It also makes publishing a scheduling constraint rather than just a permission: today that license is Hugh or Angela. Worth knowing before the queue backs up.

## Category is the whole distribution decision

It decides which screens surface the article, which audiences Penny will serve it to, and whether it appears at all. It is right that it needs the license, and right that it happens once, at the gate.

## Unavailable is a value

Usage shows as *not measured* on the Overview, because no view count or Penny-citation count is written back to the article. Filling it with something plausible would be the most damaging thing this dashboard could do — and it would hide that the fix is one write-back.

## Validated means followed, not read

`Validation Status` and `Last Tested Version` only mean something if review means following the procedure again on the current version. Reading it does not count. Eight of nine articles say Not Validated with no tested version, which is the honest state.

## Penny degrades rather than guesses

With a stale step she answers from the steps around it and says which one she is skipping. She never quotes a stale step as current and never silently repairs one — she cannot see the screen, so she would be guessing. **Degrading to a partial answer is honest; answering confidently from a six-month-old screenshot is how people stop believing her.**

## She cites the step, not the article

A citation saying "Add a user to Slack" sends someone back into 640 words. One saying step 6 is an answer — and it makes her checkable, because you can read the step she quoted and see whether she read it correctly.

## Penny does not recommend writing more articles

Nine badly structured articles do not become useful by becoming thirty. Every recommendation on the Overview removes a constraint or a risk.

## Permission shows; it does not hide

Blocked actions stay visible at 40% with the reason in the tooltip. Hiding them teaches people the system is smaller than it is; disabling them teaches who to ask.

## The schema was never the problem

The SOP record type already carries Difficulty Level, Audience, Applies To, Estimated Time Minutes, Last Tested Version, Review Frequency, Next Review Date and Validation Status. Almost all are empty. Someone modeled it properly and then had nowhere pleasant to fill it in — which is what the Article tab is for.

## Migrate the nine by hand

Splitting nine articles' `Procedure` into steps by hand is a day's work, and it is how someone notices what is already stale. An automated split would carry the staleness forward silently.
