# Handoff: Trail OS Knowledge Studio

## Overview

The **Knowledge Studio** reworks the existing Knowledge area of Trail OS so that articles are structured enough for Penny to answer from, and pleasant enough to write that people keep doing it. It sits under the existing Knowledge sidebar group, replacing **Builder**.

This is not a greenfield design. `ArticleStudio.tsx` already provides a working editor with a draft → pending-review → approved → published lifecycle and a publish-to-Salesforce step. `HelpPanel.tsx` already surfaces published articles in a 400px slide-over. **What changes is the data shape underneath them**, and everything else follows from that one change.

The governing problem: **`Procedure` is a single rich-text field carrying eleven steps.** A reader cannot find step 6, a screenshot floats in prose rather than belonging to a step, and Penny retrieves the whole wall or nothing. Restructuring it into step records is what makes the article useful to a person working alone *and* to an AI answering on their behalf — the two goals turn out to be the same goal.

The second problem is **staleness**, which the organization names as its biggest fear about knowledge. The design treats it as a first-class concern with three detectors, ranked by how fast they actually find things.

## About the design files

`designs/Knowledge Studio.dc.html` is a **design reference created as HTML** — a prototype showing intended look and behavior, not production code to copy. Recreate it inside `artifacts/program-map/` using the app's existing patterns: React + Vite + Wouter + shadcn/ui + Tailwind v4, `AppShell`, `HubShell`, `ActionBar`, `RailActionPanel`, `statusColors.ts`, and the tokens in `src/index.css`.

Do not port the inline styles. Every value came *from* the codebase; map it back to the token or component it came from.

**`reference/live-sop-article-000001002.png`** is a screenshot of a real published SOP article, supplied by the user. Most of the findings in this document come from reading it. Look at it before building.

**Reference, do not reuse:** `designs/support.js` is the prototype runtime and has no place in the app.

## Fidelity

**High fidelity.** Colors, typography, spacing, density and status semantics are final and were taken from the Trail OS codebase (`src/index.css`, `.agents/memory/admin-ux-standards.md`, `status-color-system.md`). The shell is a faithful recreation of `Topbar.tsx`, `Sidebar.tsx` and `HubShell.tsx` as they exist on `main` — reuse those, don't rebuild them.

Copy is also final, and matters more than usual here: several sentences in this design are the *definition* of a rule (what makes a finding required, why the abstract regenerates at publish). Where the prototype's copy states a constraint, treat it as spec.

## Screens

Seven tabs, split by a `w-px h-4 bg-border` separator into *authoring* (Overview, Article, Penny review, Approval) and *keeping it true* (Freshness, In-app help, Penny's read).

---

### 1. Overview — the landing tab

**Purpose:** the state of Knowledge, and what is blocking Penny.

- Amber advisory strip: nine articles exist and none is categorized; in-app help filters on category, so today it shows everything to everyone or nothing to anyone.
- Four stat cards: **Published 9** · **Categorized 0** (critical) · **Validated 1** · **Used** — rendered *unscored*, dashed border, em-dash, "Not measured" pill, because no view or Penny-citation count is written back to the article. Do not substitute a plausible number.
- **What is wrong with the articles we have** — five findings, each read from the real records: the single-field Procedure; the named person with a hedge; steps that describe destinations; no verify lines; and the audience exclusion.
- **Three moves, in this order** — Penny at Coordinator posture. Assign categories (needs the Knowledge Manager license, so it is Hugh or Angela, not whoever is free) → make Procedure a child object → put Penny's review before the approval. The order is load-bearing: she can only check what is structured, which is why review is third. Closing note: *Penny does not recommend writing more articles. Nine badly structured articles do not become useful by becoming thirty.*
- Right rail: a card noting the SOP record type already carries Difficulty Level, Audience, Applies To, Estimated Time Minutes, Last Tested Version, Review Frequency and Validation Status, almost all empty — *this is not a schema problem; someone modeled it properly and then had nowhere pleasant to fill it in*. Plus coverage against what people ask, with Coaching and Learner self-serve at none.

---

### 2. Article — the record a writer works in

**Purpose:** the screen that makes the structure worth having.

Three columns: 232px reference fields / flexible center / 300px rail.

- **Header:** record type, article number, version, status pill, and the one amber CTA — **Send to Penny for review**. Clicking it moves status to *In Penny review* and switches to that tab.
- **Left column:** Reference (owner department, difficulty, audience, applies to, estimated time) · Categories, with the note that **Trail OS** is the sub-category the help panel filters on · Review cycle, where *Validated means someone followed it start to finish on the version named above, not that someone read it*.
- **Center column, in order:**
  - **What Penny sees** — the retrieval abstract, collapsible, labelled *Not shown to readers*, not editable. Four parts: **Questions this answers** as chips phrased the way people ask them (not a précis); **What this does not cover** in a critical-role block — the load-bearing field, because it is what stops Penny answering a nearby question and sounding confident; **Answerable for**, read from the Audience field; and **Describes: version 2, current**. Footer: *generated at publish, never at creation — a stale retrieval index is worse than stale prose because it fails silently and confidently.*
  - **Overview and prerequisites** — prerequisites are rows that each **link to where they are done**, with the third row replacing the named person with `#trail-os-ops`: *a channel outlives whoever is in the role*.
  - **Procedure** — one card per step, each with a numbered chip, the instruction, a green **You should see** verify block, a **direct URL**, and a capture thumbnail stamped with the tool version it was taken against. Step 2's thumbnail is a *clip* stamped **Slack Pro, Feb 2026** in critical against an article tested Aug 2026 — staleness visible at the step. Step 4 renders in attention with a **Needs a verify line** pill and a *Penny can draft it* affordance. Footer states the payoff: steps reorder by drag, screenshots attach to a step rather than floating in prose, and Penny can answer "how do I resend an invitation" with step 6 alone.
  - **Related articles** — typed and directional. Four rows (Prerequisite / Next step / Reverses / Other side), each with the type chip, the target, and **the reason**, because the reason drives *when* Penny offers it: prerequisite before step 1 unprompted; next step only when the last step is done; reverses only when someone says they did it wrong. A Penny-suggested *Escalates to* row sits in attention. Footer: **every link is directional and writes its inverse** — a one-way relationship is how a knowledge graph quietly becomes wrong in one direction.
- **Right column:** the linked **capture session** (7 frames, 6 attached, one unattached in attention, with the rule that *a screenshot taken later is a screenshot of a different version*), Penny in Coordinator mode, and the six **relationship types** — *six deliberately; a longer list becomes a dropdown nobody reads carefully, and a wrong type is worse than no link.*

---

### 3. Penny review — before a human sees it

**Purpose:** raise the floor on every article without becoming noise the approver learns to skip.

Header counts: **3 required · 4 suggested · 6 passed**.

- **Required before approval** — critical border, "Blocks the gate" pill. Three findings, each with *Apply Penny's fix* and *Edit myself*:
  - A named person appears in a step. The hedge in the parenthesis is the tell.
  - Two steps describe a destination instead of linking to it. *A step that makes someone search is a step they abandon.*
  - Step 4 has no verify line — and Penny states she will not add it silently: *a verify line I invent and nobody tests is worse than none.*
- **Suggestions** — attention border, "Does not block" pill. Density, an unattached capture, a widen-the-audience observation framed as *a decision for you, not for me*, and a note that Slack changed this menu twice in a year so Quarterly is right.
- **Passed** — six checks shown, with the reason stated: *so the checks are inspectable, not to pad the list*.
- Right rail: the four-step review sequence (Agentforce reads and writes nothing → Penny checks on Gemini → findings split → a person approves), and **what makes something required**: it will be wrong soon, it stops the reader, or it breaks a rule we already wrote down. Everything else is a suggestion, *and keeping that line honest is what stops the review being ignored — a required list of eleven items is a list people learn to override.*

---

### 4. Approval

**Purpose:** the one gate, and the moment an article becomes reachable.

- Banner: standard Salesforce approval held by a **Knowledge Manager license** — the same license that publishes, assigns data categories and commits relationships. **Approving, categorizing, linking and publishing are one act by one person**, so an article cannot reach in-app help uncategorized or unlinked.
- **Categories, set here** — Penny proposes from the article's content and the screens it covers, with her reasoning ("four learner questions this quarter landed here from an onboarding screen"); beside it, *where this makes it appear*. Closing line: *category is the whole distribution decision — it is right that it needs the license, and right that it happens once, at the gate.*
- **Relationships, confirmed here** — rows showing type, target, the inverse it writes, and who proposed it (author or Penny). Penny's suggested link is accept-or-decline, not silently added. A link whose target is still a draft holds as **Pending** and resolves when that article publishes; *Penny never traverses an edge into a draft, so nobody has to remember to come back.*
- **Waiting on you** — three articles in the three states that matter: Penny cleared (approvable) · 2 required open (Approve **disabled with the reason visible**, not hidden) · suggestions only (approvable, with the observation that a coaching article coaches cannot read is worth a moment's thought).
- **What publishing does** — four steps: version, categories, retrieval and links (steps indexed individually, abstract regenerated, inverses written onto the linked articles), next review date set from the frequency rather than left blank.
- Right rail: **why required actions block** — *an approver reading nine articles a month will approve whatever is in front of them* — and articles due for review, where *review means following it again on the current version, then setting Last Tested Version. Reading it does not count.*

---

### 5. Freshness

**Purpose:** the organization's stated biggest fear, given a screen.

- **Three detectors, ranked honestly:** the **calendar** (reliable, always slowest — quarterly means up to three months wrong) · the **capture stamp** (a tool version moving lights up every frame below it at once) · the **reader** (fastest by a wide margin, and the card is bordered in success to say so, because *they are looking at the real screen while reading your description of it*).
- **Reader reports** — land on the **step, not the article**. Three reports on one step with a verbatim quote from a coach and a *Re-capture this step* action; one report where the capture stamp is current, read as *probably a permissions difference rather than a stale step — worth a look, not worth a re-capture*. Footer: *three reports on one step is a fact; three on one article is a shrug.*
- **Captures older than their article** — a table comparing each capture's stamp to the article's Last Tested Version, with the pattern called out: **five of seven are Slack, Feb 2026 — one session.** Stale captures cluster by tool and by session because they were taken together, so *re-capturing by session is a morning; re-capturing by article is a fortnight.*
- Right rail: Penny noticing a rename that breaks one step across three articles and offering one session to fix it; **what Penny does with a stale step** (answers from the steps around it and says which she is skipping; never quotes it as current; never silently repairs it, *because she cannot see the screen*); and **still vs clip** — a still for where something is, a clip only where a click has a consequence you cannot photograph, since *a clip on a step that only needed a still is a step that will go stale and stay stale.*

---

### 6. In-app help

**Purpose:** the panel, and the access problem blocking it.

- Critical banner: **coaches, learners and volunteers cannot open any article today** — `helpPanel.panelExclusion.test.tsx` confirms no access to the articles endpoint. Everything else on the screen assumes that is fixed.
- **How the filter should work** — data category (Trail OS plus a sub-category matching the current area) and audience. Plus the interaction note: *the panel should open on the current screen's sub-category rather than a search box. Someone who clicks Help on the Campaigns page wants the campaign articles, not a cursor.*
- **Same article, three audiences** — staff get all seven steps; a coach gets the same minus the step they have no permission for (*a step they cannot perform is not a caveat, it is a dead end*); a learner gets a different article entirely. Closing rule: **three audiences, three articles — not one article with three conditional blocks.**
- **The panel itself**, recreated at 400px: scope chips (This screen / Knowledge / All of Trail OS), a filtered count, article rows with visited state, a Penny band for when none of them answers the question, and a one-tap **"a step not matching your screen? Tell us"** row — the reader-report entry point.

---

### 7. Penny's read

**Purpose:** the argument for structure, stated as her four identities.

Four cards, each naming **the one field that identity depends on**:

- **Coach** → the verify line. "Does the members table show Transition Trails above it, or a different workspace?" Impossible from a blob — there is no verify line to ask about.
- **Coordinator** → the direct link. From a blob she would paraphrase a menu path, *which is how people end up lost*.
- **Quest Guide** → the step boundary. She can point at the next step without revealing the one after, which requires knowing where a step ends.
- **Client Liaison** → the audience field, as a wall. *Every current article is Internal, so today this is the only honest answer she has.*

Then: **she cites the step, not the article** — a citation saying "Add a user to Slack" sends someone back into 640 words; one saying step 6 is an answer, *and it makes her checkable*. A worked Slack answer with its citation chip and validation stamp. Plus **one hop, and why she stopped**: a learner asks about a Slack email, she starts on the internal article, crosses one *Other side* edge, answers from the learner article, and quotes nothing from where she started — *without that link she would have had to either refuse or leak.*

Right rail: **traversal by identity** (Coach follows Prerequisite backwards, because the reason someone is stuck is usually one article upstream; Quest Guide follows Next step forwards one hop, never two; Client Liaison follows Other side only and stops if the far article is Internal), gaps she recorded (*the writing queue should come from here rather than from what someone remembers being asked*), and four things she will not do.

## Interactions and behavior

| Trigger | Effect |
| --- | --- |
| Tab row | `overflow-x: auto`, buttons `flex-shrink: 0` — matches `HubShell.tsx`. Seven tabs overflow at narrow widths. |
| Action bar | Per-tab actions. **Blocked actions stay visible at 40% opacity, `pointer-events: none`, reason in `title`** — `ArticleBar`'s existing `disabled` / `disabledReason` contract. "Assign categories" and "Publish" are both gated this way. |
| **Send to Penny for review** | Status Draft → In Penny review; hides the CTA; switches to the review tab. |
| What Penny sees — Show / Hide | Collapses the retrieval abstract. Open by default so authors see what is indexed. |
| Apply Penny's fix | Shows the diff before writing. Never silent. |
| Approve (required open) | Disabled with the count and reason. |
| Reader report | One tap from the help panel; creates a report against the **step**. |
| Card hover | `translateY(-3px)`, shadow to `--brand-shadow-hover`, 167ms. |

## State

```
tab       'overview' | 'article' | 'review' | 'approve' | 'stale' | 'help' | 'penny'
status    'Draft' | 'In Penny review'     // the demonstrated transition
abstract  boolean                          // What Penny sees, open by default
```

Props: `viewerRole` ('staff' | 'coach' | 'learner') and `showPassedChecks` (boolean).

In the real app these become route state plus records.

## Objects

Confirm every API name against the org before building.

| Object | Role |
| --- | --- |
| `Knowledge__kav` | Existing, SOP record type. `Procedure` rich-text is **deprecated** — migrate and stop writing to it. |
| **`Procedure_Step__c`** | New. Sequence, instruction, `Verify_Line__c`, `Direct_URL__c`, capture attachment, `Captured_Against__c`. |
| `Retrieval_Abstract__c` | New. Questions answered, exclusions, audience, `Describes_Version__c`. Regenerated at publish; never hand-edited. |
| Relationship object | **API name unconfirmed.** Nothing in the app builds relationships; the SOP screenshot's Related Articles field is empty. Needs a type picklist and an inverse-writing rule. |
| `Step_Report__c` | New. A reader flag, pointing at the step. |
| `Knowledge__DataCategorySelection` | Existing. Assigned at publish under the Knowledge Manager license. |

**Migration:** the nine existing articles need `Procedure` split into steps by hand. It is nine records, and doing it by hand is how someone notices what is already stale.

## Design tokens

Take these from `src/index.css` rather than hardcoding.

| Token | Hex | Use |
| --- | --- | --- |
| `--brand-green` | #2F6B3F | Primary actions, active nav, verify blocks |
| `--brand-green-light` | #E6F0EA | Success surfaces |
| `--brand-green-medium` | #9FC3AE | Success borders, card hover |
| `--brand-teal` | #2F6F7E | Penny, informational, relationship chips |
| `--brand-sky` | #7FAFC6 | Informational borders |
| `--brand-sky-tint` | #EDF5F8 | Sidebar, Penny surfaces |
| `--brand-amber` | #F5A623 | **One CTA per screen.** Never decorative |
| `--brand-amber-dark` | #CC8400 | Attention text, suggestions |
| `--brand-critical` | #A93F2F on #FBEAE6, border #E8B9B4 | Required actions, stale captures, zero categories |
| `--brand-trail-light` | #FAFAF7 | App background |
| `--brand-warm-gray` | #E2E4E1 | Borders, dividers |
| `--brand-slate` | #4A4F4D | Body text |
| `--brand-charcoal` | #2A2E2C | Headings |
| Muted surface | #F2F3F1 | Table headers, step headers |
| Disabled | #C8CBC6 | Em dashes, dashed placeholders |

Status roles come from `config/statusColors.ts`. Never introduce a new Tailwind color family.

**Type** — Poppins 600 headings and labels; Open Sans body. Admin density per `admin-ux-standards.md`: page title 16, section heads 12, body 12–12.5, secondary 11–11.5, micro 10–10.5, stat 20–24. Uppercase card labels 10px/700, `.1em` tracking, 50% opacity. *These sit below the design system's public-facing minimums by design — this is a dense internal admin surface. Do not carry them into learner-facing or print work.*

**Spacing** — 8px base. Page padding 16, card gap 14, grid gap 10–12, card padding 12–13, table cell 7–8 × 11.

**Radius** — 8 small (steps, tables, inner blocks), 14 medium (cards, buttons), 999 pills.

**Shadow** — amber CTA only: `0 2px 8px rgba(245,166,35,.35)`. The help-panel recreation uses the card shadow `0 12px 28px rgba(42,46,44,.10)` because it represents a floating panel.

## Assets

- **Lucide** `0.462.0` via CDN in the prototype — the app already has `lucide-react`; use that. Icons follow the design system's meaning table: `lightbulb` pro tip, `triangle-alert` watch out, `key-round` access, `circle-check-big` proof it worked, `circle-slash` what it does not do, `rotate-ccw` rollback, `route` sequence, `git-branch` relationships, `image`/`play` capture kinds.
- **Capture thumbnails are placeholder tiles.** No real screenshots were available; the tiles carry their version stamp, which is the part that matters.
- No logo files — the wordmark renders in Poppins.

## Files

| File | What it is |
| --- | --- |
| `REPLIT_BRIEF.md` | Paste-ready opening instruction for the Replit agent |
| `DECISIONS.md` | The decisions and why they hold. Read before changing anything structural. |
| `designs/Knowledge Studio.dc.html` | The full design — seven tabs, all states. Open in a browser. |
| `designs/_ds/` | Transition Trails design system bundle and tokens |
| `designs/support.js` | Prototype runtime. Reference only; do not port. |
| `reference/live-sop-article-000001002.png` | Screenshot of a real published SOP article. The source of most findings. |
| `screenshots/01–07` | One per tab, in order: overview, article, penny review, approval, freshness, in-app help, penny's read |

Source of truth for the shell: `artifacts/program-map/src/components/layout/`, `src/index.css`, and `.agents/memory/`.
