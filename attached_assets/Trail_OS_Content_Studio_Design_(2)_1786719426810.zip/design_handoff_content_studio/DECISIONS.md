# Decisions

The reasoning behind the design. Read this before changing anything structural — most of these look like details and are load-bearing.

---

## Salesforce is the ledger; Drive is the bytes

No content file is uploaded into Salesforce, ever. Records carry a Drive location and a link; buyer delivery is a scoped Drive link. Salesforce CMS is a poor fit for multi-gigabyte screen recordings, and a second copy of a file is a copy that will eventually be wrong.

## Content Item is a unit of work; Product2 is a thing we sell

Keeping these in separate objects, joined by `Product_Content__c`, is what lets one piece of writing appear in a free guide, a paid kit and a bundle without being duplicated three times. The glossary insert is one content item in four kits — correct it once and every product is correct.

## The Task is the assignment

Content Item has no owner field of its own; it is a detail record hanging off Content Topic and inherits its sharing. So work is assigned with standard Tasks. The constraint and the out-of-the-box answer happen to agree.

## One gate, and it is a standard approval process

Status becomes Ready for Review, an approval routes it, approval sets Ready to Publish. No code, no Flow. It gives the editor role a real mechanism the day it is filled.

## The video gate moves to the script

Approve before anyone records. A wrong sentence costs a rewrite before recording and a full re-record after it. The same reasoning drives the capture-versus-script step check: catching a missing step before narration is rendered avoids re-rendering the audio too.

## One capture session, three outputs

The Procedure Builder session produces the video storyboard, the kit's Build pages, and a shareable how-to. Today a kit page is written from memory of a click path. This removes that entirely, and it is the single largest saving in the whole pipeline.

## The QR never encodes a platform URL

It encodes `transitiontrails.org/go/<code>`, and Trail OS redirects to whatever the publication record currently holds. Consequences: a printed kit cannot go stale, the video can move or be re-cut, and — because the code can be issued at script approval — **printing a kit never waits on a video**. Encoding the YouTube URL directly would make every printed page a liability the first time anything changed.

## Penny reviews Agentforce before a human does

Agentforce drafts, Penny reads the draft back against the source records and the voice rules, then a person approves. Two constraints keep this honest: **Penny flags what she will not fix** (she does not merge duplicate records on her own), and **the review raises the floor, it does not replace the gate** — every revision stays visible and reversible. Two models agreeing is not evidence.

## Four things no agent may do

Set a product active · set or change a price · activate an order · publish anything. Enforce in permissions, not prompts. The worst outcome of a bad agent run should be a record someone has to delete.

## Insights are record-level, not global

A global panel has to guess what you are looking at, and guesses wrong. An Insight renders on the record, view or board it concerns, in three columns — Signal, What it says, So what. The third column is the point.

**Penny receives the same block and nothing else.** One context object, two readers, so her answer and the screen cannot quote different numbers.

## Unavailable is a value

Engagement shows as *not measured* on the Overview cards, in the record Insight, and in the monthly-read agent. No inference is drawn from a number that does not exist. Filling those with something plausible would be the most damaging thing any of these screens could do — and it would hide the fact that the cheapest remaining join is the one that fixes it.

## Permission shows; it does not hide

Blocked actions stay visible at 40% with the reason in the tooltip. Hiding actions teaches people the system is smaller than it is. Disabling them teaches who to ask.

## Plan the next quarter, not this one

The Topic view defaults to next quarter; this quarter collapses to a status line with the rule that nothing new goes into it. **Runway** — weeks planned beyond today — is the single measure of whether the habit is taking, and the copy says openly that it will look bad for a while.

Empty weeks render differently by quarter: dashed and neutral in the quarter you are planning, critical in the quarter you can no longer fill.

## Always three recommendations, never a backlog

Both Penny recommendation surfaces show exactly three, ranked, with the lift each gives and the effort it costs. A list of eleven recommendations is a list nobody starts.

At the org level Penny recommends **removing constraints and risks, never publishing more**. Capacity is what the twelve-week rhythm and the content families already solve.

## One piece of work earns a family

The Topic view shows a source article with its derivatives beneath it. You do not write twelve things in twelve weeks; you write three, and each one earns a family. This is the mechanic that makes the cadence survivable, and it is why the quarter's Insight asks *which three subjects*, not *what to write thirteen times*.

## Volunteers and learners share one surface

Same work, same screens, one external-license view. Splitting them would double the surface for no behavioral difference.

## Commerce is Hugh's

The Products screen reads Product2, the junction and Asset. It never writes a price, activates a product, or configures the storefront. Activation shows as an action the studio cannot take, with the reason.

## The buyer gets a magic link, not a portal

A password is friction at exactly the wrong moment, and a near-empty dashboard for a one-kit buyer reads as unfinished. The page is scoped by the **Asset**, so ownership survives an email change. Build a real login only when someone can own three or more kits, or a bundle with pending items.

Everything else a portal would do is already solved: the QR redirect keeps printed kits current, and the Asset proves ownership without an account.

## Test data is coaching, not a bonus

Every kit ships CSVs, and each one carries the edge case its lesson needs — accounts with no children so a join visibly drops rows, a near-duplicate so a total is quietly wrong, blank fields so a filter surprises you. Tidy sample data teaches nothing.

## No price in any artifact

Prices live on the price book entry. Not in a document, a template, a page or a screen. A figure written into a design goes stale silently and then gets printed.
